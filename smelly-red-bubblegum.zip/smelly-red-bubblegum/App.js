import { Text, SafeAreaView, StyleSheet, View, Image } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Image
        style={styles.tinyLogo}
        source={{
          uri: 'https://i.pinimg.com/564x/98/b6/49/98b649da4bebb2685d8664d2ea0cbce3.jpg',
        }}
      />
      <Text style={styles.paragraph}>
        Eu passei no inova SIFUDE
      </Text>
      <View style={styles.viewEstilo}>
        <View style={{backgroundColor: 'darkturquoise', width: '100%'}}>
        <Text style={styles.paragraph}>
         Sign up
         </Text>
        </View>
      </View>
      <View style={styles.viewEstilo}>
        <View style={{backgroundColor: 'darkturquoise', width: '100%'}}>
        <Text style={styles.paragraph}>
         Log in
         </Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  viewEstilo: {
    flexDirection: 'row',
    alignSelf: 'center',
    alignContent: 'center',
    height: 75,
    width: '90%',
    backgroundColor: 'blue',
    borderWidth: 1,
    borderColor: 'black',
    marginBottom: 15,
  },
  tinyLogo: {
    width: 100,
    height: 100,
    borderRadius: 10,
    alignSelf: 'center',
    margin: 20,
  },
});
